module.exports = {
  trailingComma: 'es5',
  semi: false,
  singleQuote: true,
  jsxSingleQuote: false,
  jsxBracketSameLine: true,
  arrowParens: 'avoid',
  proseWrap: 'preserve',
  printWidth: 120,
}
